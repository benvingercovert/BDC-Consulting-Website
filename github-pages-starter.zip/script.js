function handleSubmit(e) {
  e.preventDefault();
  const result = document.getElementById('form-result');
  result.textContent = "Thanks. This demo form does not send data, but your UI works.";
  e.target.reset();
  return false;
}
document.getElementById('year').textContent = new Date().getFullYear();
