# My Website

This is a minimal starter for a GitHub Pages site.

## Local dev
Open `index.html` in your browser or use a simple server:
```bash
python -m http.server 8000
```

## Deploy on GitHub Pages
1. Create a repo on GitHub and push these files.
2. In **Settings > Pages**, set "Source" to **Deploy from a branch**, pick **main** and **/ (root)**.
3. Save. Your site will publish at `https://<your-username>.github.io/<repo-name>/`.
